source myenv/bin/activate

python3 my_driving_school/manage.py runserver